# Portfólio de Engenharia de Dados — demonstração sem faturamento

BigQuery em São Paulo, dados sintéticos e reprodução local independente da nuvem.
Validado em 29/09/2026 no projeto `fabled-web-509921-g9`.

## Resultado comprovado

- 19 tabelas e 11 visualizações criadas no BigQuery Sandbox.
- 5.642 registros exportados, incluindo dados de origem, dimensões, fatos e indicadores.
- 848 lançamentos: 827 faturados e 21 cancelados, em 18 meses.
- Faturamento sintético: R$ 3.282.277,00; margem bruta: R$ 1.363.789,70.
- Reprocessamento local das vendas e dos indicadores mensais conciliado com a exportação do BigQuery.

## Executar sem internet

Extraia o ZIP, abra um terminal nesta pasta e execute com uma instalação funcional do Python 3:

```sh
python3 scripts/reproduzir_offline.py
python3 scripts/testar_validacao.py
```

Não exige bibliotecas adicionais, credenciais ou serviços em nuvem. A execução gera `resultados/validacao.json` e `resultados/indicadores-recalculados.json`. O teste local foi feito com o Python incluído no ambiente Codex; a instalação padrão do Python deste Mac não estava pronta para uso.

## Organização

- `sql/`: carga sintética executada, visualizações e consulta de exportação.
- `data/`: exportações reais dos resultados do BigQuery, com conteúdo sintético.
- `scripts/`: reconstrução das vendas e conciliação dos indicadores.
- `resultados/`: resultados da validação local.
- `evidencias/`: capturas do Console e metadados da execução.
- `docs/`: estudo de caso, limites e roteiro para reprodução na nuvem.
- `SHA256SUMS.txt`: integridade dos arquivos do pacote, exceto o próprio manifesto.

## Custo e permanência

O projeto foi conferido sem conta de faturamento vinculada. Este pacote funciona offline e não expira. No BigQuery Sandbox, tabelas, visualizações e partições têm expiração automática de 60 dias. O pacote preserva dados, SQL e evidências para o portfólio após essa expiração; ele não mantém as tabelas online para sempre.

O Sandbox tem cotas próprias; consulte a [documentação oficial](https://docs.cloud.google.com/bigquery/docs/sandbox?hl=pt-br). Não é necessário ativar faturamento para executar a reprodução local. Não há renovação automática dos recursos em nuvem neste pacote.

## Escopo honesto

Esta entrega demonstra modelagem e análise no BigQuery, qualidade de dados e reprodução offline. A carga SQL usa reconstrução completa com dados sintéticos. **Não comprova ingestão real de PostgreSQL/API, carga incremental nem execução de Airflow.** O desenho V0.7 original previa essas etapas; sua implementação operacional continua como evolução futura. O dataset `controle` está criado, mas sem tabelas operacionais nesta demonstração.

O pacote está pronto para revisão e envio a um repositório. GitHub e LinkedIn ainda não foram publicados.
